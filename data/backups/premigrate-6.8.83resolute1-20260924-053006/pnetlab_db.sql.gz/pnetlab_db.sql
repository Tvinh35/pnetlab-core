-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: pnetlab_db
-- ------------------------------------------------------
-- Server version	8.4.11-0ubuntu0.26.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` int unsigned NOT NULL,
  `pod` int DEFAULT NULL,
  `username` varchar(150) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `category` varchar(16) NOT NULL,
  `action` varchar(32) NOT NULL,
  `lab_path` varchar(1024) DEFAULT NULL,
  `lab_name` varchar(255) DEFAULT NULL,
  `node_name` varchar(255) DEFAULT NULL,
  `node_template` varchar(64) DEFAULT NULL,
  `detail` text,
  `session_id` char(64) DEFAULT NULL,
  `duration_seconds` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_category_time` (`category`,`created_at`),
  KEY `activity_session` (`session_id`,`action`,`created_at`),
  KEY `activity_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,1790082080,44,'admin','127.0.0.1','session','login',NULL,NULL,NULL,NULL,NULL,'18fa7a085744eafe3d4134777e04f06a014845a28fcce14fc386ed64068d2396',NULL),(2,1790082268,44,'admin','192.168.137.1','session','login',NULL,NULL,NULL,NULL,NULL,'4dc6b012d3599511f46eccd57f8d21a76f3eaf9f0f4d52871f08a63e738070d5',NULL),(3,1790138283,44,'admin','192.168.137.1','session','login',NULL,NULL,NULL,NULL,NULL,'7c4377ddf865b980de1f47e0af30a760233f7c7e072e2c592ee016ab1f7d078e',NULL),(4,1790138927,44,'admin','192.168.137.1','lab','destroy','/Enterprise-AutoConfig-Internet.unl','Enterprise-AutoConfig-Internet',NULL,NULL,'{\"lab_session\":1}',NULL,NULL),(5,1790140773,44,'admin','192.168.137.1','lab','destroy','/Enterprise-AutoConfig-Internet.unl','Enterprise-AutoConfig-Internet',NULL,NULL,'{\"lab_session\":1}',NULL,NULL);
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cluster_hosts`
--

DROP TABLE IF EXISTS `cluster_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cluster_hosts` (
  `host_id` tinyint NOT NULL,
  `host_name` varchar(64) NOT NULL,
  `host_ip` varchar(45) NOT NULL,
  `host_status` tinyint NOT NULL DEFAULT '0',
  `host_last_seen` int DEFAULT NULL,
  `host_version` varchar(48) DEFAULT NULL,
  `host_joined` int DEFAULT NULL,
  PRIMARY KEY (`host_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cluster_hosts`
--

LOCK TABLES `cluster_hosts` WRITE;
/*!40000 ALTER TABLE `cluster_hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `cluster_hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cluster_placements`
--

DROP TABLE IF EXISTS `cluster_placements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cluster_placements` (
  `placement_lab` char(36) NOT NULL,
  `placement_nid` int NOT NULL,
  `placement_host` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`placement_lab`,`placement_nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cluster_placements`
--

LOCK TABLES `cluster_placements` WRITE;
/*!40000 ALTER TABLE `cluster_placements` DISABLE KEYS */;
/*!40000 ALTER TABLE `cluster_placements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `control`
--

DROP TABLE IF EXISTS `control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `control` (
  `control_name` varchar(150) NOT NULL,
  `control_value` text,
  PRIMARY KEY (`control_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control`
--

LOCK TABLES `control` WRITE;
/*!40000 ALTER TABLE `control` DISABLE KEYS */;
INSERT INTO `control` VALUES ('ctrl_captcha','0'),('ctrl_default_mode','online'),('ctrl_offline_mode','0'),('ctrl_online_mode','1'),('ctrl_version','8.2.0');
/*!40000 ALTER TABLE `control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `html5`
--

DROP TABLE IF EXISTS `html5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `html5` (
  `username` text,
  `pod` int DEFAULT NULL,
  `token` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `html5`
--

LOCK TABLES `html5` WRITE;
/*!40000 ALTER TABLE `html5` DISABLE KEYS */;
/*!40000 ALTER TABLE `html5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `if_sessions`
--

DROP TABLE IF EXISTS `if_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `if_sessions` (
  `if_session_id` bigint NOT NULL AUTO_INCREMENT,
  `if_session_lab` int DEFAULT NULL,
  `if_session_node` int DEFAULT NULL,
  `if_session_ifid` int DEFAULT NULL,
  `if_session_VlanId` int DEFAULT NULL,
  `if_session_type` varchar(150) DEFAULT NULL,
  `if_session_quality` text,
  `if_session_suspend` int DEFAULT NULL,
  PRIMARY KEY (`if_session_id`),
  KEY `if_session_ifid` (`if_session_ifid`),
  KEY `if_session_type` (`if_session_type`),
  KEY `if_session_VlanId` (`if_session_VlanId`),
  KEY `if_session_suspend` (`if_session_suspend`),
  KEY `if_session_lab` (`if_session_lab`) USING BTREE,
  KEY `if_session_node` (`if_session_node`) USING BTREE,
  CONSTRAINT `if_sessions_ibfk_1` FOREIGN KEY (`if_session_node`) REFERENCES `node_sessions` (`node_session_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=298 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `if_sessions`
--

LOCK TABLES `if_sessions` WRITE;
/*!40000 ALTER TABLE `if_sessions` DISABLE KEYS */;
INSERT INTO `if_sessions` VALUES (241,1,1,0,NULL,'ethernet',NULL,NULL),(242,1,1,16,NULL,'ethernet',NULL,NULL),(243,1,1,32,NULL,'ethernet',NULL,NULL),(244,1,1,48,NULL,'ethernet',NULL,NULL),(245,1,1,0,NULL,'ethernet',NULL,NULL),(246,1,2,0,NULL,'ethernet',NULL,NULL),(247,1,1,16,NULL,'ethernet',NULL,NULL),(248,1,1,32,NULL,'ethernet',NULL,NULL),(249,1,2,16,NULL,'ethernet',NULL,NULL),(250,1,1,48,NULL,'ethernet',NULL,NULL),(251,1,2,32,NULL,'ethernet',NULL,NULL),(252,1,2,48,NULL,'ethernet',NULL,NULL),(253,1,3,0,NULL,'ethernet',NULL,NULL),(254,1,3,16,NULL,'ethernet',NULL,NULL),(255,1,3,32,NULL,'ethernet',NULL,NULL),(256,1,3,48,NULL,'ethernet',NULL,NULL),(257,1,4,0,NULL,'ethernet',NULL,NULL),(258,1,4,16,NULL,'ethernet',NULL,NULL),(259,1,4,32,NULL,'ethernet',NULL,NULL),(260,1,4,48,NULL,'ethernet',NULL,NULL),(261,1,5,0,NULL,'ethernet',NULL,NULL),(262,1,5,16,NULL,'ethernet',NULL,NULL),(263,1,5,32,NULL,'ethernet',NULL,NULL),(264,1,5,48,NULL,'ethernet',NULL,NULL),(265,1,6,0,NULL,'ethernet',NULL,NULL),(266,1,6,16,NULL,'ethernet',NULL,NULL),(267,1,6,32,NULL,'ethernet',NULL,NULL),(268,1,6,48,NULL,'ethernet',NULL,NULL),(269,1,7,0,NULL,'ethernet',NULL,NULL),(270,1,7,16,NULL,'ethernet',NULL,NULL),(271,1,7,32,NULL,'ethernet',NULL,NULL),(272,1,7,48,NULL,'ethernet',NULL,NULL),(273,1,8,0,NULL,'ethernet',NULL,NULL),(274,1,8,16,NULL,'ethernet',NULL,NULL),(275,1,8,32,NULL,'ethernet',NULL,NULL),(276,1,8,48,NULL,'ethernet',NULL,NULL),(277,1,9,0,NULL,'ethernet',NULL,NULL),(278,1,9,16,NULL,'ethernet',NULL,NULL),(279,1,9,32,NULL,'ethernet',NULL,NULL),(280,1,9,48,NULL,'ethernet',NULL,NULL),(281,1,10,0,NULL,'ethernet',NULL,NULL),(282,1,10,16,NULL,'ethernet',NULL,NULL),(283,1,10,32,NULL,'ethernet',NULL,NULL),(284,1,10,48,NULL,'ethernet',NULL,NULL),(285,1,11,0,NULL,'ethernet',NULL,NULL),(286,1,11,16,NULL,'ethernet',NULL,NULL),(287,1,11,32,NULL,'ethernet',NULL,NULL),(288,1,11,48,NULL,'ethernet',NULL,NULL),(289,1,12,0,NULL,'ethernet',NULL,NULL),(290,1,13,0,NULL,'ethernet',NULL,NULL),(291,1,14,0,NULL,'ethernet',NULL,NULL),(292,1,15,0,NULL,'ethernet',NULL,NULL),(293,1,16,0,NULL,'ethernet',NULL,NULL),(294,1,17,0,NULL,'ethernet',NULL,NULL),(295,1,18,0,NULL,'ethernet',NULL,NULL),(296,1,19,0,NULL,'ethernet',NULL,NULL),(297,1,20,0,NULL,'ethernet',NULL,NULL);
/*!40000 ALTER TABLE `if_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lab_sessions`
--

DROP TABLE IF EXISTS `lab_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lab_sessions` (
  `lab_session_id` int NOT NULL AUTO_INCREMENT,
  `lab_session_lid` varchar(150) DEFAULT NULL,
  `lab_session_pod` int DEFAULT NULL,
  `lab_session_joined` text,
  `lab_session_path` text,
  `lab_session_running` int DEFAULT NULL,
  PRIMARY KEY (`lab_session_id`) USING BTREE,
  KEY `lab_session_lid` (`lab_session_lid`) USING BTREE,
  KEY `lab_session_pod` (`lab_session_pod`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_sessions`
--

LOCK TABLES `lab_sessions` WRITE;
/*!40000 ALTER TABLE `lab_sessions` DISABLE KEYS */;
INSERT INTO `lab_sessions` VALUES (1,'7db52088-16d7-450d-9a4a-9fe73e76018a',44,'44','/Enterprise-20Nodes-Internet.unl',NULL);
/*!40000 ALTER TABLE `lab_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_sessions`
--

DROP TABLE IF EXISTS `node_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_sessions` (
  `node_session_id` int NOT NULL,
  `node_session_nid` int DEFAULT NULL,
  `node_session_lab` int DEFAULT NULL,
  `node_session_port` int DEFAULT NULL,
  `node_session_type` varchar(150) DEFAULT NULL,
  `node_session_workspace` text,
  `node_session_ram` float DEFAULT NULL,
  `node_session_cpu` float DEFAULT NULL,
  `node_session_hdd` float DEFAULT NULL,
  `node_session_running` int DEFAULT NULL,
  `node_session_pod` int DEFAULT NULL,
  `node_session_iol` int DEFAULT NULL,
  `node_cpu` float DEFAULT '0',
  `node_ram` int DEFAULT '0',
  `node_session_port_2nd` int DEFAULT NULL,
  `node_session_host` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`node_session_id`) USING BTREE,
  UNIQUE KEY `node_session_nid_2` (`node_session_nid`,`node_session_lab`),
  KEY `node_session_lab` (`node_session_lab`),
  KEY `node_session_port` (`node_session_port`),
  KEY `node_session_nid` (`node_session_nid`),
  KEY `node_session_type` (`node_session_type`),
  KEY `node_session_running` (`node_session_running`),
  KEY `node_session_pod` (`node_session_pod`),
  KEY `node_session_iol` (`node_session_iol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_sessions`
--

LOCK TABLES `node_sessions` WRITE;
/*!40000 ALTER TABLE `node_sessions` DISABLE KEYS */;
INSERT INTO `node_sessions` VALUES (1,1,1,30001,'iol','/opt/unetlab/tmp/1/1',NULL,NULL,NULL,0,44,1,0,0,40001,0),(2,2,1,30002,'iol','/opt/unetlab/tmp/1/2',NULL,NULL,NULL,0,44,2,0,0,40002,0),(3,3,1,30003,'iol','/opt/unetlab/tmp/1/3',NULL,NULL,NULL,0,44,3,0,0,40003,0),(4,4,1,30004,'iol','/opt/unetlab/tmp/1/4',NULL,NULL,NULL,0,44,4,0,0,40004,0),(5,5,1,30005,'iol','/opt/unetlab/tmp/1/5',NULL,NULL,NULL,0,44,5,0,0,40005,0),(6,6,1,30006,'iol','/opt/unetlab/tmp/1/6',NULL,NULL,NULL,0,44,6,0,0,40006,0),(7,7,1,30007,'iol','/opt/unetlab/tmp/1/7',NULL,NULL,NULL,0,44,7,0,0,40007,0),(8,8,1,30008,'iol','/opt/unetlab/tmp/1/8',NULL,NULL,NULL,0,44,8,0,0,40008,0),(9,9,1,30009,'iol','/opt/unetlab/tmp/1/9',NULL,NULL,NULL,0,44,9,0,0,40009,0),(10,10,1,30010,'iol','/opt/unetlab/tmp/1/10',NULL,NULL,NULL,0,44,10,0,0,40010,0),(11,11,1,30011,'iol','/opt/unetlab/tmp/1/11',NULL,NULL,NULL,0,44,11,0,0,40011,0),(12,12,1,30012,'vpcs','/opt/unetlab/tmp/1/12',NULL,NULL,NULL,0,44,NULL,0,0,40012,0),(13,13,1,30013,'vpcs','/opt/unetlab/tmp/1/13',NULL,NULL,NULL,0,44,NULL,0,0,40013,0),(14,14,1,30014,'vpcs','/opt/unetlab/tmp/1/14',NULL,NULL,NULL,0,44,NULL,0,0,40014,0),(15,15,1,30015,'vpcs','/opt/unetlab/tmp/1/15',NULL,NULL,NULL,0,44,NULL,0,0,40015,0),(16,16,1,30016,'vpcs','/opt/unetlab/tmp/1/16',NULL,NULL,NULL,0,44,NULL,0,0,40016,0),(17,17,1,30017,'vpcs','/opt/unetlab/tmp/1/17',NULL,NULL,NULL,0,44,NULL,0,0,40017,0),(18,18,1,30018,'vpcs','/opt/unetlab/tmp/1/18',NULL,NULL,NULL,0,44,NULL,0,0,40018,0),(19,19,1,30019,'vpcs','/opt/unetlab/tmp/1/19',NULL,NULL,NULL,0,44,NULL,0,0,40019,0),(20,20,1,30020,'vpcs','/opt/unetlab/tmp/1/20',NULL,NULL,NULL,0,44,NULL,0,0,40020,0);
/*!40000 ALTER TABLE `node_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `pod` int NOT NULL,
  `created_at` int unsigned NOT NULL,
  `expires_at` int unsigned NOT NULL,
  `used_at` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_resets_token` (`token_hash`),
  KEY `password_resets_pod` (`pod`,`used_at`),
  KEY `password_resets_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process`
--

DROP TABLE IF EXISTS `process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process` (
  `process_id` varchar(200) NOT NULL,
  `process_dtotal` int DEFAULT NULL,
  `process_dnow` int DEFAULT NULL,
  `process_utotal` int DEFAULT NULL,
  `process_unow` int DEFAULT NULL,
  `process_finish` int DEFAULT NULL,
  PRIMARY KEY (`process_id`),
  KEY `process_dtotal` (`process_dtotal`),
  KEY `process_dnow` (`process_dnow`),
  KEY `process_utotal` (`process_utotal`),
  KEY `process_unow` (`process_unow`),
  KEY `process_finish` (`process_finish`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process`
--

LOCK TABLES `process` WRITE;
/*!40000 ALTER TABLE `process` DISABLE KEYS */;
/*!40000 ALTER TABLE `process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_device`
--

DROP TABLE IF EXISTS `process_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_device` (
  `process_device_id` varchar(150) NOT NULL,
  `process_device_dtotal` int DEFAULT NULL,
  `process_device_dnow` int DEFAULT NULL,
  `process_device_utotal` int DEFAULT NULL,
  `process_device_unow` int DEFAULT NULL,
  `process_device_log` text,
  UNIQUE KEY `process_device_id` (`process_device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_device`
--

LOCK TABLES `process_device` WRITE;
/*!40000 ALTER TABLE `process_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_version`
--

DROP TABLE IF EXISTS `schema_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_version` (
  `version` int NOT NULL,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_version`
--

LOCK TABLES `schema_version` WRITE;
/*!40000 ALTER TABLE `schema_version` DISABLE KEYS */;
INSERT INTO `schema_version` VALUES (1,'2026-09-22 13:00:12','users.user_max_cpu'),(2,'2026-09-22 13:00:12','users.user_max_ram'),(3,'2026-09-22 13:00:12','users.access_days'),(4,'2026-09-22 13:00:12','users.ext_auth'),(5,'2026-09-22 13:00:12','node_sessions.node_cpu'),(6,'2026-09-22 13:00:12','node_sessions.node_ram'),(7,'2026-09-22 13:00:12','node_sessions.node_session_port_2nd'),(8,'2026-09-22 13:00:12','node_sessions.node_session_host'),(9,'2026-09-22 13:00:12','cluster_hosts'),(10,'2026-09-22 13:00:12','cluster_placements'),(11,'2026-09-22 13:00:12','activity_log'),(12,'2026-09-22 13:00:12','password_resets');
/*!40000 ALTER TABLE `schema_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permission`
--

DROP TABLE IF EXISTS `user_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permission` (
  `user_per_id` int NOT NULL AUTO_INCREMENT,
  `user_per_role` int DEFAULT NULL,
  `user_per_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`user_per_id`),
  KEY `user_per_role` (`user_per_role`),
  KEY `user_per_name` (`user_per_name`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permission`
--

LOCK TABLES `user_permission` WRITE;
/*!40000 ALTER TABLE `user_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_role_id` int NOT NULL AUTO_INCREMENT,
  `user_role_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `user_role_workspace` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `user_role_note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `user_role_ram` float DEFAULT NULL,
  `user_role_cpu` float DEFAULT NULL,
  `user_role_hdd` float DEFAULT NULL,
  PRIMARY KEY (`user_role_id`),
  KEY `user_role_name` (`user_role_name`),
  KEY `user_role_ram` (`user_role_ram`),
  KEY `user_role_cpu` (`user_role_cpu`),
  KEY `user_role_hdd` (`user_role_hdd`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `pod` int NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `cookie` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `email` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `expiration` int DEFAULT '-1',
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `password` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `session` int DEFAULT NULL,
  `ip` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `role` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `folder` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `lab_session` int DEFAULT NULL,
  `html5` tinyint(1) DEFAULT NULL,
  `license` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `online_time` int DEFAULT NULL,
  `note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `offline` int DEFAULT NULL,
  `active_time` int DEFAULT NULL,
  `expired_time` int DEFAULT NULL,
  `user_status` int DEFAULT '1',
  `user_workspace` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `max_node` int DEFAULT NULL,
  `max_node_lab` int DEFAULT NULL,
  `user_max_cpu` int DEFAULT NULL,
  `user_max_ram` int DEFAULT NULL,
  `access_days` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ext_auth` varchar(8) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`pod`),
  UNIQUE KEY `email` (`email`),
  KEY `online_time` (`online_time`),
  KEY `lab_session` (`lab_session`),
  KEY `offline` (`offline`),
  KEY `active_time` (`active_time`),
  KEY `expired_time` (`expired_time`),
  KEY `user_status` (`user_status`),
  KEY `max_node` (`max_node`),
  KEY `max_node_lab` (`max_node_lab`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (44,'admin','12f8c5994b1bd05a3aafb99558870283d9fb8394',NULL,-1,NULL,'fcfcbba4e322bb69d53fe0f8a2b03d7f3c37ee3fb3d51864785c899aaeaaeb5d',1790144789,'192.168.137.1','0','/',1,1,NULL,1790141176,NULL,0,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiresharks`
--

DROP TABLE IF EXISTS `wiresharks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wiresharks` (
  `ws_id` bigint NOT NULL AUTO_INCREMENT,
  `ws_tenant` int DEFAULT NULL,
  `ws_lab` varchar(200) DEFAULT NULL,
  `ws_node` int DEFAULT NULL,
  `ws_if` int DEFAULT NULL,
  `ws_net` int DEFAULT NULL,
  `ws_node_name` varchar(150) DEFAULT NULL,
  `ws_if_name` varchar(150) DEFAULT NULL,
  `ws_dc_name` varchar(150) DEFAULT NULL,
  `ws_port` int DEFAULT NULL,
  `ws_ip` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`ws_id`),
  KEY `ws_ip` (`ws_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiresharks`
--

LOCK TABLES `wiresharks` WRITE;
/*!40000 ALTER TABLE `wiresharks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiresharks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-24  5:30:06
